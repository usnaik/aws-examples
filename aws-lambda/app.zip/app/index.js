exports.handler = function (event, context, callback) {

	console.log('Creating lambda from CLI');
	console.log('Úpdating lambda function from aws cli ...');
	callback(null,'success');
};
